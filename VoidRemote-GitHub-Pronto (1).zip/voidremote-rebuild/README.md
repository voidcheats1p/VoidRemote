# VOID CHEATS / VoidRemote — reconstrução inicial

Este pacote contém um projeto Android nativo em Kotlin e uma API Node.js para validação e administração de Keys.

## Importante sobre o APK original
O ZIP recebido contém somente `app-debug.apk`; não contém código-fonte. Portanto, esta é uma reconstrução inicial, não uma edição do projeto original.

## Android
1. Abra esta pasta no Android Studio (versão compatível com Android Gradle Plugin 8.7.3).
2. Em `app/src/main/java/com/voidcheats/remote/MainActivity.kt`, substitua `https://SEU-BACKEND.com` pela URL HTTPS da API publicada.
3. Sincronize o Gradle e gere o APK em **Build → Build APK(s)**.

O ambiente usado para preparar este pacote não possui Android SDK/Gradle instalados, então não foi possível compilar ou testar um APK nesta sessão.

## API de Keys
Requer Node.js 18+.

```bash
cd backend
npm install
ADMIN_PASSWORD='troque-esta-senha' npm start
```

Configure `ADMIN_PASSWORD` como variável secreta do provedor de hospedagem. Não use senha administrativa no código do aplicativo. O banco JSON `keys.json` deve ficar em armazenamento persistente e privado.

Rotas:
- `POST /admin/login` com `{ "password": "..." }`
- `POST /admin/keys` com Bearer token e `{ "duration": "3h|1d|7d|1m", "quantity": 1 }`
- `GET /admin/keys` com Bearer token
- `POST /admin/keys/:key/revoke` com Bearer token
- `POST /api/keys/validate` com `{ "key": "..." }`

A validade começa na primeira ativação. `1m` equivale a 30 dias.

## Depuração sem fio
O app mostra o fluxo de orientação, mas não ativa a Depuração sem fio nem concede autorização ADB sozinho. O usuário precisa habilitar e autorizar o pareamento nas configurações do próprio Android. O botão CONECTAR, nesta versão inicial, é informativo; não executa comandos ADB nem altera jogos.

Os itens Aimbot/ESP são apenas opções visuais de interface. Não implementam mira automática, ESP funcional, injeção ou evasão de anti-cheat.

## Gerar APK pelo GitHub
1. Envie o conteúdo desta pasta para um repositório GitHub (a pasta `.github/workflows` precisa ir junto).
2. Abra a aba **Actions** do repositório.
3. Selecione **Build Android APK** e clique em **Run workflow** (ou faça um push na branch `main`).
4. Quando terminar com sucesso, abra a execução e baixe o artefato **void-cheats-debug-apk**. Dentro dele estará `app-debug.apk`.

Observação: o APK pode ser compilado sem a API publicada, mas a validação de Keys só funcionará depois de hospedar a API e configurar a URL HTTPS no `MainActivity.kt`, conforme a seção Android acima. O artefato debug é para testes; distribuição pública exige assinatura de release.
