package com.voidcheats.remote

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val purple = Color.rgb(168, 85, 247)
    private val bg = Color.rgb(9, 6, 17)
    private val panel = Color.rgb(23, 16, 35)
    private lateinit var root: LinearLayout
    private lateinit var keyInput: EditText
    private lateinit var ipInput: EditText
    private lateinit var portInput: EditText
    private lateinit var pairCodeInput: EditText
    private lateinit var status: TextView
    private lateinit var featurePanel: LinearLayout
    private var unlocked = false

    // Configure this with the HTTPS URL of your deployed backend before building.
    private val apiBase = "https://SEU-BACKEND.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 24); setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val banner = ImageView(this).apply { setImageResource(R.drawable.void_banner); adjustViewBounds = true; scaleType = ImageView.ScaleType.CENTER_CROP }
        content.addView(banner, LinearLayout.LayoutParams(-1, 175))
        content.addView(label("VOID CHEATS", 27, Color.WHITE, true))
        content.addView(label("REMOTE CONTROL • ANDROID", 11, purple, true))
        content.addView(section("1. DEPURAÇÃO SEM FIO"))
        content.addView(label("No Android: Opções do desenvolvedor → Depuração sem fio → Parear dispositivo com código. Faça o pareamento nas configurações do sistema; o app não ativa isso sozinho.", 13, Color.LTGRAY, false))
        ipInput = field("IP do dispositivo (ex.: 192.168.1.10)")
        portInput = field("Porta de pareamento")
        pairCodeInput = field("Código de pareamento")
        content.addView(ipInput); content.addView(portInput); content.addView(pairCodeInput)
        content.addView(actionButton("INSTRUÇÕES DE PAREAMENTO") { showPairingHelp() })
        content.addView(section("2. VALIDAR KEY"))
        keyInput = field("Digite sua Key")
        content.addView(keyInput)
        content.addView(actionButton("VALIDAR KEY") { validateKey() })
        status = label("Aguardando conexão e validação.", 13, Color.LTGRAY, false)
        content.addView(status)
        featurePanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        featurePanel.addView(section("3. PAINEL VOID"))
        listOf("AIMBOT LEGIT", "AIMBOT RAGE", "ESP 2D", "ESP 3D").forEach { name ->
            val check = CheckBox(this).apply { text = name; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(purple) }
            featurePanel.addView(check)
        }
        featurePanel.addView(actionButton("CONECTAR") {
            Toast.makeText(this, "Conclua o pareamento ADB nas configurações do Android. Este painel não injeta nem modifica jogos.", Toast.LENGTH_LONG).show()
        })
        content.addView(featurePanel)
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun validateKey() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) { status.text = "Digite uma Key."; return }
        status.text = "Validando no servidor..."
        thread {
            try {
                val conn = (URL("$apiBase/api/keys/validate").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 10000; readTimeout = 10000; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use { it.write(JSONObject().put("key", key).toString().toByteArray()) }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                runOnUiThread {
                    if (conn.responseCode in 200..299 && json.optBoolean("valid")) {
                        unlocked = true; featurePanel.visibility = View.VISIBLE
                        status.text = "KEY VÁLIDA • ${json.optString("expiresAt", "ativa")}"; status.setTextColor(Color.GREEN)
                    } else status.text = json.optString("error", "Key inválida ou expirada.")
                }
                conn.disconnect()
            } catch (_: Exception) { runOnUiThread { status.text = "Não foi possível acessar o servidor. Configure a URL da API." } }
        }
    }

    private fun showPairingHelp() {
        AlertDialog.Builder(this).setTitle("Pareamento ADB")
            .setMessage("1. Ative as Opções do desenvolvedor.\n2. Abra Depuração sem fio.\n3. Toque em Parear dispositivo com código.\n4. Use o IP, a porta e o código exibidos pelo Android no fluxo de pareamento ADB compatível.\n\nO app não consegue habilitar a depuração nem concluir autorização silenciosamente.")
            .setPositiveButton("OK", null).show()
    }

    private fun section(text: String) = label(text, 15, purple, true).apply { setPadding(0, 22, 0, 8) }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        gravity = Gravity.CENTER; setPadding(4, 8, 4, 8)
    }
    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 14f
        setSingleLine(true); setPadding(16, 12, 16, 12); background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = 14f; setStroke(1, purple) }
        val lp = LinearLayout.LayoutParams(-1, 52); lp.setMargins(0, 6, 0, 6); layoutParams = lp
    }
    private fun actionButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(purple); setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(-1, 52); lp.setMargins(0, 8, 0, 8); layoutParams = lp
    }
}
