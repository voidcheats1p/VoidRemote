import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const app = express();
app.use(express.json({ limit: '32kb' }));
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const DB_FILE = process.env.DB_FILE || path.join(process.cwd(), 'keys.json');
const sessions = new Map();

if (!ADMIN_PASSWORD) {
  console.error('Defina ADMIN_PASSWORD no ambiente antes de iniciar.');
  process.exit(1);
}
function readDb() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch { return { keys: [] }; }
}
function writeDb(db) {
  const temp = `${DB_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(temp, DB_FILE);
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const exp = sessions.get(token);
  if (!exp || exp < Date.now()) return res.status(401).json({ error: 'Não autorizado.' });
  next();
}
function makeKey() { return `VOID-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`; }
const durations = { '3h': 3 * 3600000, '1d': 86400000, '7d': 7 * 86400000, '1m': 30 * 86400000 };

app.get('/health', (_req, res) => res.json({ ok: true }));
app.post('/api/keys/validate', (req, res) => {
  const key = String(req.body?.key || '').trim();
  const db = readDb();
  const item = db.keys.find(k => k.key === key && !k.revoked);
  if (!item) return res.status(403).json({ valid: false, error: 'Key inválida ou revogada.' });
  const now = Date.now();
  if (!item.activatedAt) { item.activatedAt = now; item.expiresAt = now + durations[item.duration]; writeDb(db); }
  if (now >= item.expiresAt) return res.status(403).json({ valid: false, error: 'Key expirada.' });
  res.json({ valid: true, expiresAt: new Date(item.expiresAt).toISOString() });
});
app.post('/admin/login', (req, res) => {
  const supplied = String(req.body?.password || '');
  const a = Buffer.from(supplied), b = Buffer.from(ADMIN_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Senha incorreta.' });
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now() + 8 * 3600000);
  res.json({ token, expiresIn: 28800 });
});
app.get('/admin/keys', auth, (_req, res) => res.json(readDb().keys));
app.post('/admin/keys', auth, (req, res) => {
  const duration = String(req.body?.duration || '');
  const quantity = Math.min(100, Math.max(1, Number(req.body?.quantity || 1)));
  if (!durations[duration]) return res.status(400).json({ error: 'Duração deve ser 3h, 1d, 7d ou 1m.' });
  const db = readDb();
  const created = Array.from({ length: quantity }, () => ({ key: makeKey(), duration, createdAt: Date.now(), activatedAt: null, expiresAt: null, revoked: false }));
  db.keys.push(...created); writeDb(db); res.status(201).json(created);
});
app.post('/admin/keys/:key/revoke', auth, (req, res) => {
  const db = readDb(); const item = db.keys.find(k => k.key === req.params.key);
  if (!item) return res.status(404).json({ error: 'Key não encontrada.' });
  item.revoked = true; writeDb(db); res.json({ ok: true });
});
app.listen(PORT, () => console.log(`VOID Remote API listening on ${PORT}`));
